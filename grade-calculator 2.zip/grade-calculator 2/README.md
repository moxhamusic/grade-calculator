# Simple Grade Calculator

A simple JavaScript project that calculates a student's total marks, average, and letter grade for 5 subjects using conditional (if-else) logic.

## 📁 Folder Structure

```
grade-calculator/
├── index.html          # Main HTML page
├── css/
│   └── style.css        # Styling
├── js/
│   └── script.js         # Grade calculation logic
└── README.md
```

## 🚀 How It Works

1. Click **"Start Calculation"** on the page.
2. The browser will prompt you (using `prompt()`) to enter marks for 5 subjects, one at a time.
3. The script:
   - Adds up the marks to get the **Total**.
   - Divides the total by 5 to get the **Average**.
   - Uses `if-else` statements to assign a **Grade**:
     - 90 and above → A+
     - 80–89 → A
     - 70–79 → B
     - 60–69 → C
     - 50–59 → D
     - 40–49 → E
     - Below 40 → F (Fail)
4. Results are shown in an `alert()` popup, and also displayed on the page.

## 🧪 Testing

Open `index.html` directly in any browser (double-click the file, or use a local server) and test with different mark combinations, including:
- All high marks (e.g. 95, 92, 88, 90, 96) → should give A+/A
- Mixed marks around grade boundaries (e.g. 60, 59, 70, 69, 50) → check boundaries work correctly
- Low marks (e.g. 20, 30, 15, 25, 10) → should give F
- Invalid input (letters, empty, out-of-range numbers) → should re-prompt until valid
- Clicking "Cancel" on a prompt → should stop gracefully
